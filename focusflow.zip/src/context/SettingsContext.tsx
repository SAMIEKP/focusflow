import React, { createContext, useContext, useState, useEffect } from 'react';
import { FocusSchedule, AppLimit } from '../types';

type Theme = 'System' | 'Dark' | 'Light';

interface SettingsContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  appIcon: string;
  setAppIcon: (icon: string) => void;
  trackingEnabled: boolean;
  setTrackingEnabled: (enabled: boolean) => void;
  focusDuration: number;
  setFocusDuration: (duration: number) => void;
  shortBreakDuration: number;
  setShortBreakDuration: (duration: number) => void;
  longBreakDuration: number;
  setLongBreakDuration: (duration: number) => void;
  startSound: string;
  setStartSound: (sound: string) => void;
  endSound: string;
  setEndSound: (sound: string) => void;
  transitionSound: string;
  setTransitionSound: (sound: string) => void;
  reminderTime: string;
  setReminderTime: (time: string) => void;
  focusReminderTime: string;
  setFocusReminderTime: (time: string) => void;
  weeklyReportEnabled: boolean;
  setWeeklyReportEnabled: (enabled: boolean) => void;
  limitWarningsEnabled: boolean;
  setLimitWarningsEnabled: (enabled: boolean) => void;
  ignoreBackgroundEnabled: boolean;
  setIgnoreBackgroundEnabled: (enabled: boolean) => void;
  schedules: FocusSchedule[];
  addSchedule: (schedule: Omit<FocusSchedule, 'id'>) => void;
  updateSchedule: (id: string, schedule: Partial<FocusSchedule>) => void;
  deleteSchedule: (id: string) => void;
  limits: AppLimit[];
  addLimit: (limit: Omit<AppLimit, 'id'>) => void;
  updateLimit: (id: string, limit: Partial<AppLimit>) => void;
  deleteLimit: (id: string) => void;
  downtimeEnabled: boolean;
  setDowntimeEnabled: (enabled: boolean) => void;
  downtimeStart: string;
  setDowntimeStart: (time: string) => void;
  downtimeEnd: string;
  setDowntimeEnd: (time: string) => void;
  notificationStrictness: 'Strict' | 'Gentle' | 'Off';
  setNotificationStrictness: (strictness: 'Strict' | 'Gentle' | 'Off') => void;
  alwaysAllowedApps: string[];
  setAlwaysAllowedApps: (apps: string[]) => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SOUND_OPTIONS = {
  start: [
    { id: 'pop', name: 'Pop', url: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3' },
    { id: 'click', name: 'Click', url: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3' },
    { id: 'blip', name: 'Blip', url: 'https://assets.mixkit.co/active_storage/sfx/2572/2572-preview.mp3' },
  ],
  end: [
    { id: 'chime', name: 'Chime', url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
    { id: 'bell', name: 'Bell', url: 'https://assets.mixkit.co/active_storage/sfx/2567/2567-preview.mp3' },
    { id: 'success', name: 'Success', url: 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3' },
  ],
  transition: [
    { id: 'swish', name: 'Swish', url: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3' },
    { id: 'slide', name: 'Slide', url: 'https://assets.mixkit.co/active_storage/sfx/2570/2570-preview.mp3' },
    { id: 'whoosh', name: 'Whoosh', url: 'https://assets.mixkit.co/active_storage/sfx/2569/2569-preview.mp3' },
  ]
};

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('focusflow-theme');
    return (saved as Theme) || 'Dark';
  });

  const [appIcon, setAppIcon] = useState(() => {
    return localStorage.getItem('focusflow-icon') || 'default';
  });

  const [trackingEnabled, setTrackingEnabled] = useState(() => {
    const saved = localStorage.getItem('focusflow-tracking');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [focusDuration, setFocusDuration] = useState(() => {
    const saved = localStorage.getItem('focusflow-focus-duration');
    return saved !== null ? parseInt(saved) : 25;
  });

  const [shortBreakDuration, setShortBreakDuration] = useState(() => {
    const saved = localStorage.getItem('focusflow-short-break-duration');
    return saved !== null ? parseInt(saved) : 5;
  });

  const [longBreakDuration, setLongBreakDuration] = useState(() => {
    const saved = localStorage.getItem('focusflow-long-break-duration');
    return saved !== null ? parseInt(saved) : 15;
  });

  const [startSound, setStartSound] = useState(() => {
    return localStorage.getItem('focusflow-start-sound') || SOUND_OPTIONS.start[0].url;
  });

  const [endSound, setEndSound] = useState(() => {
    return localStorage.getItem('focusflow-end-sound') || SOUND_OPTIONS.end[0].url;
  });

  const [transitionSound, setTransitionSound] = useState(() => {
    return localStorage.getItem('focusflow-transition-sound') || SOUND_OPTIONS.transition[0].url;
  });

  const [reminderTime, setReminderTime] = useState(() => {
    return localStorage.getItem('focusflow-reminder-time') || '09:00';
  });

  const [focusReminderTime, setFocusReminderTime] = useState(() => {
    return localStorage.getItem('focusflow-focus-reminder-time') || '10:00';
  });

  const [weeklyReportEnabled, setWeeklyReportEnabled] = useState(() => {
    const saved = localStorage.getItem('focusflow-weekly-report');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [limitWarningsEnabled, setLimitWarningsEnabled] = useState(() => {
    const saved = localStorage.getItem('focusflow-limit-warnings');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [ignoreBackgroundEnabled, setIgnoreBackgroundEnabled] = useState(() => {
    const saved = localStorage.getItem('focusflow-ignore-background');
    return saved !== null ? JSON.parse(saved) : false;
  });

  const [schedules, setSchedules] = useState<FocusSchedule[]>(() => {
    const saved = localStorage.getItem('focusflow-schedules');
    return saved !== null ? JSON.parse(saved) : [];
  });

  const [limits, setLimits] = useState<AppLimit[]>(() => {
    const saved = localStorage.getItem('focusflow-limits');
    if (saved !== null) {
      const parsed = JSON.parse(saved);
      return parsed.map((l: any) => ({
        ...l,
        type: l.type || 'category'
      }));
    }
    
    // Default limits
    return [
      { id: 'social', type: 'category', title: 'Social Media', subtitle: 'Instagram, TikTok, X', limit: '1h 30m', color: 'bg-blue-500', icon: 'Users', enabled: true },
      { id: 'entertainment', type: 'category', title: 'Entertainment', subtitle: 'Netflix, YouTube', limit: '2h 00m', color: 'bg-orange-500', icon: 'Clapperboard', enabled: true },
      { id: 'productivity', type: 'category', title: 'Productivity', subtitle: 'Mail, Notes, Calendar', limit: 'No Limit', color: 'bg-green-500', icon: 'CheckCircle', enabled: true },
    ];
  });

  useEffect(() => {
    localStorage.setItem('focusflow-theme', theme);
    const root = window.document.documentElement;
    
    if (theme === 'Light') {
      root.classList.remove('dark');
    } else if (theme === 'Dark') {
      root.classList.add('dark');
    } else {
      // System
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      if (systemTheme === 'dark') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('focusflow-icon', appIcon);
  }, [appIcon]);

  useEffect(() => {
    localStorage.setItem('focusflow-tracking', JSON.stringify(trackingEnabled));
  }, [trackingEnabled]);

  useEffect(() => {
    localStorage.setItem('focusflow-focus-duration', focusDuration.toString());
  }, [focusDuration]);

  useEffect(() => {
    localStorage.setItem('focusflow-short-break-duration', shortBreakDuration.toString());
  }, [shortBreakDuration]);

  useEffect(() => {
    localStorage.setItem('focusflow-long-break-duration', longBreakDuration.toString());
  }, [longBreakDuration]);

  useEffect(() => {
    localStorage.setItem('focusflow-start-sound', startSound);
  }, [startSound]);

  useEffect(() => {
    localStorage.setItem('focusflow-end-sound', endSound);
  }, [endSound]);

  useEffect(() => {
    localStorage.setItem('focusflow-transition-sound', transitionSound);
  }, [transitionSound]);

  useEffect(() => {
    localStorage.setItem('focusflow-reminder-time', reminderTime);
  }, [reminderTime]);

  useEffect(() => {
    localStorage.setItem('focusflow-focus-reminder-time', focusReminderTime);
  }, [focusReminderTime]);

  useEffect(() => {
    localStorage.setItem('focusflow-weekly-report', JSON.stringify(weeklyReportEnabled));
  }, [weeklyReportEnabled]);

  useEffect(() => {
    localStorage.setItem('focusflow-limit-warnings', JSON.stringify(limitWarningsEnabled));
  }, [limitWarningsEnabled]);

  useEffect(() => {
    localStorage.setItem('focusflow-ignore-background', JSON.stringify(ignoreBackgroundEnabled));
  }, [ignoreBackgroundEnabled]);

  useEffect(() => {
    localStorage.setItem('focusflow-schedules', JSON.stringify(schedules));
  }, [schedules]);

  useEffect(() => {
    localStorage.setItem('focusflow-limits', JSON.stringify(limits));
  }, [limits]);

  const addSchedule = (schedule: Omit<FocusSchedule, 'id'>) => {
    const newSchedule = { ...schedule, id: crypto.randomUUID() };
    setSchedules([...schedules, newSchedule]);
  };

  const updateSchedule = (id: string, updatedFields: Partial<FocusSchedule>) => {
    setSchedules(schedules.map(s => s.id === id ? { ...s, ...updatedFields } : s));
  };

  const deleteSchedule = (id: string) => {
    setSchedules(schedules.filter(s => s.id !== id));
  };

  const addLimit = (limit: Omit<AppLimit, 'id'>) => {
    const newLimit = { ...limit, id: crypto.randomUUID() };
    setLimits([...limits, newLimit]);
  };

  const updateLimit = (id: string, updatedFields: Partial<AppLimit>) => {
    setLimits(limits.map(l => l.id === id ? { ...l, ...updatedFields } : l));
  };

  const deleteLimit = (id: string) => {
    setLimits(limits.filter(l => l.id !== id));
  };

  const [downtimeEnabled, setDowntimeEnabled] = useState(() => {
    const saved = localStorage.getItem('focusflow-downtime-enabled');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [downtimeStart, setDowntimeStart] = useState(() => {
    return localStorage.getItem('focusflow-downtime-start') || '22:00';
  });

  const [downtimeEnd, setDowntimeEnd] = useState(() => {
    return localStorage.getItem('focusflow-downtime-end') || '07:00';
  });

  const [notificationStrictness, setNotificationStrictness] = useState<'Strict' | 'Gentle' | 'Off'>(() => {
    return (localStorage.getItem('focusflow-notification-strictness') as any) || 'Strict';
  });

  const [alwaysAllowedApps, setAlwaysAllowedApps] = useState<string[]>(() => {
    const saved = localStorage.getItem('focusflow-always-allowed');
    return saved !== null ? JSON.parse(saved) : ['Phone', 'Messages', 'Maps', 'Calendar'];
  });

  useEffect(() => {
    localStorage.setItem('focusflow-downtime-enabled', JSON.stringify(downtimeEnabled));
  }, [downtimeEnabled]);

  useEffect(() => {
    localStorage.setItem('focusflow-downtime-start', downtimeStart);
  }, [downtimeStart]);

  useEffect(() => {
    localStorage.setItem('focusflow-downtime-end', downtimeEnd);
  }, [downtimeEnd]);

  useEffect(() => {
    localStorage.setItem('focusflow-notification-strictness', notificationStrictness);
  }, [notificationStrictness]);

  useEffect(() => {
    localStorage.setItem('focusflow-always-allowed', JSON.stringify(alwaysAllowedApps));
  }, [alwaysAllowedApps]);

  return (
    <SettingsContext.Provider value={{ 
      theme, setTheme, 
      appIcon, setAppIcon, 
      trackingEnabled, setTrackingEnabled,
      focusDuration, setFocusDuration,
      shortBreakDuration, setShortBreakDuration,
      longBreakDuration, setLongBreakDuration,
      startSound, setStartSound,
      endSound, setEndSound,
      transitionSound, setTransitionSound,
      reminderTime, setReminderTime,
      focusReminderTime, setFocusReminderTime,
      weeklyReportEnabled, setWeeklyReportEnabled,
      limitWarningsEnabled, setLimitWarningsEnabled,
      ignoreBackgroundEnabled, setIgnoreBackgroundEnabled,
      schedules, addSchedule, updateSchedule, deleteSchedule,
      limits, addLimit, updateLimit, deleteLimit,
      downtimeEnabled, setDowntimeEnabled,
      downtimeStart, setDowntimeStart,
      downtimeEnd, setDowntimeEnd,
      notificationStrictness, setNotificationStrictness,
      alwaysAllowedApps, setAlwaysAllowedApps
    }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
